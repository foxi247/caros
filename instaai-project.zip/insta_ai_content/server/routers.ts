import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { invokeLLM } from "./_core/llm";
import {
  createCarouselPost,
  getCarouselPostById,
  getCarouselPostsForUser,
  createCarouselSlides,
  getCarouselSlidesForPost,
  createGenerationSession,
  getOrCreateOnboardingProgress,
  updateOnboardingProgress,
  getAllUsers,
  getConnectedAccountsStats,
  getScheduledPostsStats,
  getRecentCarouselPosts,
  getInstagramAccountsForUser,
  createInstagramAccount,
} from "./db";
import { TRPCError } from "@trpc/server";

// Input validation schemas
const generateContentSchema = z.object({
  niche: z.string().min(1),
  toneOfVoice: z.string().min(1),
  language: z.string().min(1),
  targetAudience: z.string().min(1),
});

const adminProcedure = protectedProcedure.use(async ({ ctx, next }) => {
  if (ctx.user?.role !== "admin") {
    throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Content Generation APIs
  content: router({
    // Generate carousel content using AI
    generateCarousel: publicProcedure
      .input(generateContentSchema)
      .mutation(async ({ input }) => {
        const startTime = Date.now();

        try {
          // Generate post ideas and captions using LLM
          const generationPrompt = `You are an expert Instagram content creator. Generate a carousel post for the following:
- Niche/Business: ${input.niche}
- Tone of Voice: ${input.toneOfVoice}
- Language: ${input.language}
- Target Audience: ${input.targetAudience}

Please provide:
1. A catchy post title
2. An engaging main caption (150-200 words)
3. 5-8 carousel slides with compelling text for each slide
4. Visual style suggestions for the carousel
5. Color scheme recommendations

Format your response as JSON with the following structure:
{
  "title": "string",
  "caption": "string",
  "visualStyle": "string",
  "colorScheme": "string",
  "slides": [
    {
      "slideNumber": number,
      "slideText": "string",
      "visualDescription": "string",
      "textAlignment": "center" | "left" | "right"
    }
  ]
}`;

          const response = await invokeLLM({
            messages: [
              {
                role: "system",
                content: "You are an expert Instagram content creator. Always respond with valid JSON only.",
              },
              {
                role: "user",
                content: generationPrompt,
              },
            ],
            response_format: {
              type: "json_schema",
              json_schema: {
                name: "carousel_content",
                strict: true,
                schema: {
                  type: "object",
                  properties: {
                    title: { type: "string" },
                    caption: { type: "string" },
                    visualStyle: { type: "string" },
                    colorScheme: { type: "string" },
                    slides: {
                      type: "array",
                      items: {
                        type: "object",
                        properties: {
                          slideNumber: { type: "number" },
                          slideText: { type: "string" },
                          visualDescription: { type: "string" },
                          textAlignment: { type: "string", enum: ["center", "left", "right"] },
                        },
                        required: ["slideNumber", "slideText", "visualDescription", "textAlignment"],
                        additionalProperties: false,
                      },
                    },
                  },
                  required: ["title", "caption", "visualStyle", "colorScheme", "slides"],
                  additionalProperties: false,
                },
              },
            },
          });

          const messageContent = response.choices[0]?.message.content;
          const contentStr = typeof messageContent === 'string' ? messageContent : JSON.stringify(messageContent);
          const content = JSON.parse(contentStr || "{}");
          const generationTimeMs = Date.now() - startTime;

          // Create carousel post in database
          const postResult = await createCarouselPost({
            title: content.title,
            niche: input.niche,
            toneOfVoice: input.toneOfVoice,
            language: input.language,
            targetAudience: input.targetAudience,
            caption: content.caption,
            visualStyle: content.visualStyle,
            slideCount: content.slides.length,
          });

          // Fetch the created post to get its ID
          const createdPost = await getRecentCarouselPosts(1);
          if (!createdPost || createdPost.length === 0) {
            throw new Error("Failed to retrieve created post");
          }
          const postId = createdPost[0].id;

          // Create carousel slides
          const slidesData = content.slides.map((slide: any) => ({
            postId,
            slideNumber: slide.slideNumber,
            slideText: slide.slideText,
            visualDescription: slide.visualDescription,
            colorScheme: content.colorScheme,
            textAlignment: slide.textAlignment,
          }));

          await createCarouselSlides(slidesData);

          // Create generation session
          await createGenerationSession({
            postId,
            generationPrompt,
            generationModel: "gpt-4",
            generationTimeMs,
          });

          // Fetch the complete post with slides
          const post = await getCarouselPostById(postId);
          const slides = await getCarouselSlidesForPost(postId);

          return {
            success: true,
            post,
            slides,
            generationTimeMs,
          };
        } catch (error) {
          console.error("[Content Generation] Error:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to generate carousel content",
          });
        }
      }),

    // Get carousel post with slides
    getCarousel: publicProcedure
      .input(z.object({ postId: z.number() }))
      .query(async ({ input }) => {
        const post = await getCarouselPostById(input.postId);
        if (!post) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Post not found" });
        }

        const slides = await getCarouselSlidesForPost(input.postId);
        return { post, slides };
      }),

    // Get recent carousels (for demo or user)
    getRecent: publicProcedure
      .input(z.object({ limit: z.number().default(10) }).optional())
      .query(async ({ input }) => {
        return getRecentCarouselPosts(input?.limit || 10);
      }),
  }),

  // Onboarding APIs
  onboarding: router({
    getProgress: protectedProcedure.query(async ({ ctx }) => {
      return getOrCreateOnboardingProgress(ctx.user.id);
    }),

    updateProgress: protectedProcedure
      .input(z.object({ step: z.number(), isCompleted: z.boolean().optional() }))
      .mutation(async ({ ctx, input }) => {
        return updateOnboardingProgress(ctx.user.id, input.step, input.isCompleted);
      }),
  }),

  // Instagram Account APIs
  instagram: router({
    // Get connected accounts for user
    getAccounts: protectedProcedure.query(async ({ ctx }) => {
      return getInstagramAccountsForUser(ctx.user.id);
    }),

    // Store Instagram OAuth token (called after OAuth flow)
    connectAccount: protectedProcedure
      .input(
        z.object({
          instagramUsername: z.string(),
          instagramUserId: z.string(),
          accessToken: z.string(),
          refreshToken: z.string().optional(),
          tokenExpiresAt: z.date().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        try {
          await createInstagramAccount({
            userId: ctx.user.id,
            instagramUsername: input.instagramUsername,
            instagramUserId: input.instagramUserId,
            accessToken: input.accessToken,
            refreshToken: input.refreshToken,
            tokenExpiresAt: input.tokenExpiresAt,
            isConnected: true,
          });

          return { success: true };
        } catch (error) {
          console.error("[Instagram] Connection error:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Failed to connect Instagram account",
          });
        }
      }),

    // Placeholder for future Instagram publishing
    publishPost: protectedProcedure
      .input(z.object({ postId: z.number(), instagramAccountId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        // This is a placeholder for future Instagram API integration
        return {
          success: false,
          message: "Instagram publishing coming soon. OAuth integration required.",
        };
      }),
  }),

  // Admin Dashboard APIs
  admin: router({
    // Get all users (admin only)
    getUsers: adminProcedure.query(async () => {
      return getAllUsers();
    }),

    // Get connected accounts stats
    getConnectedAccounts: adminProcedure.query(async () => {
      return getConnectedAccountsStats();
    }),

    // Get scheduled posts stats
    getScheduledPosts: adminProcedure.query(async () => {
      return getScheduledPostsStats();
    }),

    // Get dashboard stats
    getStats: adminProcedure.query(async () => {
      const users = await getAllUsers(1000);
      const accounts = await getConnectedAccountsStats();
      const posts = await getRecentCarouselPosts(1000);
      const scheduledPosts = await getScheduledPostsStats();

      return {
        totalUsers: users.length,
        connectedAccounts: accounts.length,
        totalPosts: posts.length,
        scheduledPosts: scheduledPosts.length,
        users,
        accounts,
        posts,
      };
    }),
  }),
});

export type AppRouter = typeof appRouter;

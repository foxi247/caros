import { eq, and, isNull, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, carouselPosts, carouselSlides, instagramAccounts, generationSessions, onboardingProgress } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Carousel Posts queries
export async function createCarouselPost(post: typeof carouselPosts.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(carouselPosts).values(post);
  return result;
}

export async function getCarouselPostById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.select().from(carouselPosts).where(eq(carouselPosts.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getCarouselPostsForUser(userId: number | null) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  if (userId === null) {
    // Demo posts
    return db.select().from(carouselPosts).where(isNull(carouselPosts.userId)).orderBy(desc(carouselPosts.createdAt));
  }
  
  return db.select().from(carouselPosts).where(eq(carouselPosts.userId, userId)).orderBy(desc(carouselPosts.createdAt));
}

export async function getRecentCarouselPosts(limit: number = 10) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.select().from(carouselPosts).orderBy(desc(carouselPosts.createdAt)).limit(limit);
}

// Carousel Slides queries
export async function createCarouselSlides(slides: (typeof carouselSlides.$inferInsert)[]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.insert(carouselSlides).values(slides);
}

export async function getCarouselSlidesForPost(postId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.select().from(carouselSlides).where(eq(carouselSlides.postId, postId)).orderBy(carouselSlides.slideNumber);
}

// Instagram Accounts queries
export async function createInstagramAccount(account: typeof instagramAccounts.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.insert(instagramAccounts).values(account);
}

export async function getInstagramAccountsForUser(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.select().from(instagramAccounts).where(eq(instagramAccounts.userId, userId));
}

export async function getInstagramAccountById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.select().from(instagramAccounts).where(eq(instagramAccounts.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// Generation Sessions queries
export async function createGenerationSession(session: typeof generationSessions.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.insert(generationSessions).values(session);
}

export async function getGenerationSessionsForPost(postId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.select().from(generationSessions).where(eq(generationSessions.postId, postId));
}

// Onboarding Progress queries
export async function getOrCreateOnboardingProgress(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const existing = await db.select().from(onboardingProgress).where(eq(onboardingProgress.userId, userId)).limit(1);
  
  if (existing.length > 0) {
    return existing[0];
  }
  
  await db.insert(onboardingProgress).values({ userId, step: 0, isCompleted: false });
  const result = await db.select().from(onboardingProgress).where(eq(onboardingProgress.userId, userId)).limit(1);
  return result[0];
}

export async function updateOnboardingProgress(userId: number, step: number, isCompleted: boolean = false) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const updateData: Record<string, unknown> = { step };
  if (isCompleted) {
    updateData.isCompleted = true;
    updateData.completedAt = new Date();
  }
  
  return db.update(onboardingProgress).set(updateData).where(eq(onboardingProgress.userId, userId));
}

// Admin dashboard queries
export async function getAllUsers(limit: number = 100) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.select().from(users).orderBy(desc(users.createdAt)).limit(limit);
}

export async function getConnectedAccountsStats() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.select().from(instagramAccounts).orderBy(desc(instagramAccounts.createdAt));
}

export async function getScheduledPostsStats() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return db.select().from(carouselPosts).where(eq(carouselPosts.isScheduled, true)).orderBy(desc(carouselPosts.scheduledFor));
}

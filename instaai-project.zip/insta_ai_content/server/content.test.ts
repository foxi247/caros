import { describe, expect, it, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock the database functions
vi.mock("./db", () => ({
  createCarouselPost: vi.fn().mockResolvedValue({ insertId: 1 }),
  getCarouselPostById: vi.fn().mockResolvedValue({
    id: 1,
    title: "Test Post",
    niche: "Tech",
    toneOfVoice: "Professional",
    language: "English",
    targetAudience: "Developers",
    caption: "Test caption",
    visualStyle: "Modern",
    slideCount: 5,
    userId: null,
    isScheduled: false,
    isPublished: false,
    createdAt: new Date(),
    updatedAt: new Date(),
  }),
  createCarouselSlides: vi.fn().mockResolvedValue({}),
  getCarouselSlidesForPost: vi.fn().mockResolvedValue([
    {
      id: 1,
      postId: 1,
      slideNumber: 1,
      slideText: "Slide 1 text",
      visualDescription: "Modern design",
      colorScheme: "Blue",
      textAlignment: "center",
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ]),
  createGenerationSession: vi.fn().mockResolvedValue({}),
  getRecentCarouselPosts: vi.fn().mockResolvedValue([
    {
      id: 1,
      title: "Test Carousel",
      niche: "Tech",
      toneOfVoice: "Professional",
      language: "English",
      targetAudience: "Developers",
      caption: "Test caption content",
      visualStyle: "Modern minimalist",
      slideCount: 1,
      userId: null,
      isScheduled: false,
      isPublished: false,
      scheduledFor: null,
      publishedAt: null,
      instagramPostId: null,
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ]),
}));

// Mock the LLM function
vi.mock("./_core/llm", () => ({
  invokeLLM: vi.fn().mockResolvedValue({
    choices: [
      {
        message: {
          content: JSON.stringify({
            title: "Test Carousel",
            caption: "Test caption content",
            visualStyle: "Modern minimalist",
            colorScheme: "Blue and white",
            slides: [
              {
                slideNumber: 1,
                slideText: "Slide 1 text",
                visualDescription: "Modern design",
                textAlignment: "center",
              },
            ],
          }),
        },
      },
    ],
  }),
}));

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: vi.fn(),
    } as unknown as TrpcContext["res"],
  };
}

describe("content.generateCarousel", () => {
  it("generates carousel content with valid input", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.content.generateCarousel({
      niche: "Tech",
      toneOfVoice: "Professional",
      language: "English",
      targetAudience: "Developers",
    });

    expect(result.success).toBe(true);
    expect(result.post).toBeDefined();
    expect(result.slides).toBeDefined();
    expect(result.generationTimeMs).toBeGreaterThanOrEqual(0);
  });

  it("requires all input fields", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.content.generateCarousel({
        niche: "",
        toneOfVoice: "Professional",
        language: "English",
        targetAudience: "Developers",
      });
      expect.fail("Should have thrown validation error");
    } catch (error: any) {
      expect(error.code).toBe("BAD_REQUEST");
    }
  });
});

describe("content.getCarousel", () => {
  it("retrieves carousel post with slides", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.content.getCarousel({ postId: 1 });

    expect(result.post).toBeDefined();
    expect(result.slides).toBeDefined();
    expect(result.slides.length).toBeGreaterThan(0);
  });
});

describe("content.getRecent", () => {
  it("retrieves recent carousel posts", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.content.getRecent({ limit: 10 });

    expect(Array.isArray(result)).toBe(true);
  });
});

import { invokeLLM } from "./server/_core/llm.ts";

async function testLLM() {
  try {
    console.log("Testing LLM integration...");
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: "You are a helpful assistant. Respond with JSON.",
        },
        {
          role: "user",
          content: "Generate a simple JSON with title and description",
        },
      ],
    });
    console.log("LLM Response:", JSON.stringify(response, null, 2));
  } catch (error) {
    console.error("LLM Error:", error);
  }
}

testLLM();

import fetch from 'node-fetch';

const payload = {
  json: {
    niche: "Technology",
    toneOfVoice: "Professional",
    language: "English",
    targetAudience: "Developers"
  }
};

console.log("Sending payload:", JSON.stringify(payload, null, 2));

const response = await fetch("http://localhost:3000/api/trpc/content.generateCarousel", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(payload)
});

const result = await response.json();
console.log("Response status:", response.status);
console.log("Response:", JSON.stringify(result, null, 2));

if (result.error?.json?.data?.stack) {
  console.log("\nError Stack:");
  console.log(result.error.json.data.stack);
}

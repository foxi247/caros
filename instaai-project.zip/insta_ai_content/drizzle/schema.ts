import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, json, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Instagram accounts connected to user accounts.
 * Stores OAuth tokens and account metadata for future Instagram API integration.
 */
export const instagramAccounts = mysqlTable("instagram_accounts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  instagramUsername: varchar("instagramUsername", { length: 255 }).notNull(),
  instagramUserId: varchar("instagramUserId", { length: 255 }).notNull().unique(),
  accessToken: text("accessToken"), // Will be encrypted in production
  refreshToken: text("refreshToken"),
  tokenExpiresAt: timestamp("tokenExpiresAt"),
  isConnected: boolean("isConnected").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type InstagramAccount = typeof instagramAccounts.$inferSelect;
export type InsertInstagramAccount = typeof instagramAccounts.$inferInsert;

/**
 * Generated carousel posts with all content and metadata.
 */
export const carouselPosts = mysqlTable("carousel_posts", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"), // null for demo mode posts
  title: varchar("title", { length: 255 }).notNull(),
  niche: varchar("niche", { length: 100 }).notNull(),
  toneOfVoice: varchar("toneOfVoice", { length: 100 }).notNull(),
  language: varchar("language", { length: 50 }).notNull(),
  targetAudience: varchar("targetAudience", { length: 255 }).notNull(),
  caption: text("caption").notNull(),
  visualStyle: varchar("visualStyle", { length: 255 }),
  slideCount: int("slideCount").notNull(),
  isScheduled: boolean("isScheduled").default(false).notNull(),
  scheduledFor: timestamp("scheduledFor"),
  isPublished: boolean("isPublished").default(false).notNull(),
  publishedAt: timestamp("publishedAt"),
  instagramPostId: varchar("instagramPostId", { length: 255 }), // Instagram API post ID after publishing
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CarouselPost = typeof carouselPosts.$inferSelect;
export type InsertCarouselPost = typeof carouselPosts.$inferInsert;

/**
 * Individual carousel slides with text and visual suggestions.
 */
export const carouselSlides = mysqlTable("carousel_slides", {
  id: int("id").autoincrement().primaryKey(),
  postId: int("postId").notNull(),
  slideNumber: int("slideNumber").notNull(),
  slideText: text("slideText").notNull(),
  visualDescription: text("visualDescription"), // Description for visual style (for future Canva integration)
  colorScheme: varchar("colorScheme", { length: 500 }), // e.g., "vibrant", "minimalist", "pastel" or detailed color descriptions with hex codes
  textAlignment: varchar("textAlignment", { length: 50 }).default("center"), // left, center, right
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CarouselSlide = typeof carouselSlides.$inferSelect;
export type InsertCarouselSlide = typeof carouselSlides.$inferInsert;

/**
 * Content generation sessions for tracking demo and user-generated content.
 */
export const generationSessions = mysqlTable("generation_sessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId"), // null for demo mode
  postId: int("postId").notNull(),
  generationPrompt: text("generationPrompt").notNull(),
  generationModel: varchar("generationModel", { length: 100 }).default("gpt-4").notNull(),
  generationTimeMs: int("generationTimeMs"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type GenerationSession = typeof generationSessions.$inferSelect;
export type InsertGenerationSession = typeof generationSessions.$inferInsert;

/**
 * User onboarding progress tracking.
 */
export const onboardingProgress = mysqlTable("onboarding_progress", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique(),
  step: int("step").default(0).notNull(), // 0: welcome, 1: niche selection, 2: first generation, 3: instagram connect, 4: complete
  isCompleted: boolean("isCompleted").default(false).notNull(),
  completedAt: timestamp("completedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type OnboardingProgress = typeof onboardingProgress.$inferSelect;
export type InsertOnboardingProgress = typeof onboardingProgress.$inferInsert;

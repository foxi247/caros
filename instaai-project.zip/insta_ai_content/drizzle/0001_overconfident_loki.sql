CREATE TABLE `carousel_posts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`title` varchar(255) NOT NULL,
	`niche` varchar(100) NOT NULL,
	`toneOfVoice` varchar(100) NOT NULL,
	`language` varchar(50) NOT NULL,
	`targetAudience` varchar(255) NOT NULL,
	`caption` text NOT NULL,
	`visualStyle` varchar(255),
	`slideCount` int NOT NULL,
	`isScheduled` boolean NOT NULL DEFAULT false,
	`scheduledFor` timestamp,
	`isPublished` boolean NOT NULL DEFAULT false,
	`publishedAt` timestamp,
	`instagramPostId` varchar(255),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `carousel_posts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `carousel_slides` (
	`id` int AUTO_INCREMENT NOT NULL,
	`postId` int NOT NULL,
	`slideNumber` int NOT NULL,
	`slideText` text NOT NULL,
	`visualDescription` text,
	`colorScheme` varchar(100),
	`textAlignment` varchar(50) DEFAULT 'center',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `carousel_slides_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `generation_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int,
	`postId` int NOT NULL,
	`generationPrompt` text NOT NULL,
	`generationModel` varchar(100) NOT NULL DEFAULT 'gpt-4',
	`generationTimeMs` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `generation_sessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `instagram_accounts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`instagramUsername` varchar(255) NOT NULL,
	`instagramUserId` varchar(255) NOT NULL,
	`accessToken` text,
	`refreshToken` text,
	`tokenExpiresAt` timestamp,
	`isConnected` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `instagram_accounts_id` PRIMARY KEY(`id`),
	CONSTRAINT `instagram_accounts_instagramUserId_unique` UNIQUE(`instagramUserId`)
);
--> statement-breakpoint
CREATE TABLE `onboarding_progress` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`step` int NOT NULL DEFAULT 0,
	`isCompleted` boolean NOT NULL DEFAULT false,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `onboarding_progress_id` PRIMARY KEY(`id`),
	CONSTRAINT `onboarding_progress_userId_unique` UNIQUE(`userId`)
);

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import type { GenerationInput, GenerationResult } from "@/types";

interface ContentGenerationFormProps {
  onSuccess?: (result: GenerationResult) => void;
  isLoading?: boolean;
}

const NICHES = [
  "Technology",
  "Fashion",
  "Beauty",
  "Fitness",
  "Nutrition",
  "Travel",
  "Business",
  "Marketing",
  "Education",
  "Entertainment",
  "Lifestyle",
  "Finance",
  "Health",
  "DIY & Crafts",
  "Photography",
];

const TONES = [
  "Professional",
  "Casual",
  "Humorous",
  "Inspirational",
  "Educational",
  "Storytelling",
  "Trendy",
  "Minimalist",
  "Bold",
  "Friendly",
];

const LANGUAGES = [
  "English",
  "Spanish",
  "French",
  "German",
  "Italian",
  "Portuguese",
  "Japanese",
  "Chinese",
  "Arabic",
  "Hindi",
];

const AUDIENCES = [
  "Gen Z (13-24)",
  "Millennials (25-40)",
  "Gen X (41-56)",
  "Baby Boomers (57+)",
  "Entrepreneurs",
  "Students",
  "Professionals",
  "Parents",
  "Fitness Enthusiasts",
  "Tech Enthusiasts",
];

export function ContentGenerationForm({ onSuccess, isLoading: externalIsLoading }: ContentGenerationFormProps) {
  const [formData, setFormData] = useState<GenerationInput>({
    niche: "",
    toneOfVoice: "",
    language: "English",
    targetAudience: "",
  });

  const generateMutation = trpc.content.generateCarousel.useMutation({
    onSuccess: (result) => {
      toast.success("Content generated successfully!");
      if (result.post) {
        onSuccess?.(result as any);
      }
    },
    onError: (error) => {
      toast.error(error.message || "Failed to generate content");
    },
  });

  const isLoading = externalIsLoading || generateMutation.isPending;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.niche || !formData.toneOfVoice || !formData.targetAudience) {
      toast.error("Please fill in all fields");
      return;
    }

    generateMutation.mutate(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="w-full space-y-6">
      <div className="space-y-2">
        <label className="block text-sm font-semibold text-foreground">
          Niche / Business Type
        </label>
        <Select value={formData.niche} onValueChange={(value) => setFormData({ ...formData, niche: value })}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="Select your niche..." />
          </SelectTrigger>
          <SelectContent>
            {NICHES.map((niche) => (
              <SelectItem key={niche} value={niche}>
                {niche}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <label className="block text-sm font-semibold text-foreground">
          Tone of Voice
        </label>
        <Select value={formData.toneOfVoice} onValueChange={(value) => setFormData({ ...formData, toneOfVoice: value })}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="Select tone..." />
          </SelectTrigger>
          <SelectContent>
            {TONES.map((tone) => (
              <SelectItem key={tone} value={tone}>
                {tone}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <label className="block text-sm font-semibold text-foreground">
          Language
        </label>
        <Select value={formData.language} onValueChange={(value) => setFormData({ ...formData, language: value })}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="Select language..." />
          </SelectTrigger>
          <SelectContent>
            {LANGUAGES.map((lang) => (
              <SelectItem key={lang} value={lang}>
                {lang}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <label className="block text-sm font-semibold text-foreground">
          Target Audience
        </label>
        <Select value={formData.targetAudience} onValueChange={(value) => setFormData({ ...formData, targetAudience: value })}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder="Select audience..." />
          </SelectTrigger>
          <SelectContent>
            {AUDIENCES.map((audience) => (
              <SelectItem key={audience} value={audience}>
                {audience}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <Button
        type="submit"
        disabled={isLoading}
        className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold py-3 rounded-lg transition-smooth"
      >
        {isLoading ? (
          <>
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            Generating Content...
          </>
        ) : (
          "Generate Content"
        )}
      </Button>

      {generateMutation.isPending && (
        <div className="text-center text-sm text-muted-foreground">
          <p>Creating your carousel content with AI...</p>
        </div>
      )}
    </form>
  );
}

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Sparkles, Zap, Instagram, CheckCircle2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

interface OnboardingFlowProps {
  isOpen: boolean;
  onClose: () => void;
}

const ONBOARDING_STEPS = [
  {
    id: 0,
    title: "Welcome to InstaAI",
    description: "Create amazing Instagram carousels with AI in seconds",
    icon: Sparkles,
    content: (
      <div className="space-y-4">
        <p className="text-muted-foreground">
          InstaAI helps you generate engaging carousel posts tailored to your niche and audience.
        </p>
        <div className="space-y-3">
          <div className="flex gap-3">
            <Zap className="w-5 h-5 text-accent flex-shrink-0 mt-1" />
            <div>
              <p className="font-semibold text-foreground">Lightning Fast</p>
              <p className="text-sm text-muted-foreground">Generate complete carousels in seconds</p>
            </div>
          </div>
          <div className="flex gap-3">
            <Sparkles className="w-5 h-5 text-accent flex-shrink-0 mt-1" />
            <div>
              <p className="font-semibold text-foreground">AI-Powered</p>
              <p className="text-sm text-muted-foreground">Advanced AI tailored to your content style</p>
            </div>
          </div>
          <div className="flex gap-3">
            <Instagram className="w-5 h-5 text-accent flex-shrink-0 mt-1" />
            <div>
              <p className="font-semibold text-foreground">Instagram Ready</p>
              <p className="text-sm text-muted-foreground">Preview exactly how it looks on Instagram</p>
            </div>
          </div>
        </div>
      </div>
    ),
  },
  {
    id: 1,
    title: "Choose Your Niche",
    description: "Tell us about your business or content focus",
    icon: Sparkles,
    content: (
      <div className="space-y-4">
        <p className="text-muted-foreground">
          Select the niche that best describes your business or content focus. This helps us generate more relevant content.
        </p>
        <div className="grid grid-cols-2 gap-3">
          {["Tech", "Fashion", "Fitness", "Business", "Beauty", "Travel"].map((niche) => (
            <button
              key={niche}
              className="p-3 rounded-lg border border-border hover:border-accent hover:bg-accent/5 transition-smooth text-sm font-medium text-foreground"
            >
              {niche}
            </button>
          ))}
        </div>
      </div>
    ),
  },
  {
    id: 2,
    title: "Generate Your First Post",
    description: "Create your first carousel post",
    icon: Zap,
    content: (
      <div className="space-y-4">
        <p className="text-muted-foreground">
          Head to the demo section and fill out the content generation form. You'll see your carousel preview instantly!
        </p>
        <div className="glass-card p-4 space-y-2">
          <p className="text-sm font-semibold text-foreground">What you'll do:</p>
          <ol className="text-sm text-muted-foreground space-y-1 list-decimal list-inside">
            <li>Select your niche and tone of voice</li>
            <li>Choose your target audience</li>
            <li>Click "Generate Content"</li>
            <li>See your carousel preview instantly</li>
          </ol>
        </div>
      </div>
    ),
  },
  {
    id: 3,
    title: "Connect Instagram",
    description: "Publish directly to your Instagram account",
    icon: Instagram,
    content: (
      <div className="space-y-4">
        <p className="text-muted-foreground">
          Connect your Instagram account to publish carousels directly from InstaAI.
        </p>
        <div className="glass-card p-4 space-y-3">
          <p className="text-sm font-semibold text-foreground">Coming Soon:</p>
          <ul className="text-sm text-muted-foreground space-y-2">
            <li className="flex gap-2">
              <CheckCircle2 className="w-4 h-4 text-accent flex-shrink-0 mt-0.5" />
              <span>One-click Instagram publishing</span>
            </li>
            <li className="flex gap-2">
              <CheckCircle2 className="w-4 h-4 text-accent flex-shrink-0 mt-0.5" />
              <span>Schedule posts for optimal times</span>
            </li>
            <li className="flex gap-2">
              <CheckCircle2 className="w-4 h-4 text-accent flex-shrink-0 mt-0.5" />
              <span>Track performance analytics</span>
            </li>
          </ul>
        </div>
      </div>
    ),
  },
  {
    id: 4,
    title: "You're All Set!",
    description: "Start creating amazing content",
    icon: CheckCircle2,
    content: (
      <div className="space-y-4 text-center">
        <div className="w-16 h-16 rounded-full bg-accent/20 flex items-center justify-center mx-auto">
          <CheckCircle2 className="w-8 h-8 text-accent" />
        </div>
        <p className="text-muted-foreground">
          You're ready to start creating amazing Instagram content with InstaAI. Happy creating!
        </p>
      </div>
    ),
  },
];

export function OnboardingFlow({ isOpen, onClose }: OnboardingFlowProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const updateProgressMutation = trpc.onboarding.updateProgress.useMutation();

  const step = ONBOARDING_STEPS[currentStep];
  const Icon = step?.icon;
  const isLastStep = currentStep === ONBOARDING_STEPS.length - 1;

  const handleNext = async () => {
    if (isLastStep) {
      await updateProgressMutation.mutateAsync({
        step: ONBOARDING_STEPS.length - 1,
        isCompleted: true,
      });
      onClose();
    } else {
      setCurrentStep((prev) => prev + 1);
      await updateProgressMutation.mutateAsync({
        step: currentStep + 1,
      });
    }
  };

  const handleSkip = async () => {
    await updateProgressMutation.mutateAsync({
      step: ONBOARDING_STEPS.length - 1,
      isCompleted: true,
    });
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <div className="flex items-center gap-3 mb-4">
            {Icon && <Icon className="w-6 h-6 text-accent" />}
            <div>
              <DialogTitle>{step?.title}</DialogTitle>
              <DialogDescription>{step?.description}</DialogDescription>
            </div>
          </div>
        </DialogHeader>

        <div className="py-6">{step?.content}</div>

        {/* Progress Indicators */}
        <div className="flex gap-1 mb-6">
          {ONBOARDING_STEPS.map((_, index) => (
            <div
              key={index}
              className={`h-1 flex-1 rounded-full transition-smooth ${
                index <= currentStep ? "bg-accent" : "bg-muted"
              }`}
            />
          ))}
        </div>

        {/* Actions */}
        <div className="flex gap-3">
          <Button variant="outline" onClick={handleSkip} className="flex-1">
            Skip
          </Button>
          <Button
            onClick={handleNext}
            className="flex-1 bg-accent hover:bg-accent/90 text-accent-foreground font-semibold"
          >
            {isLastStep ? "Get Started" : "Next"}
          </Button>
        </div>

        <p className="text-xs text-muted-foreground text-center mt-4">
          Step {currentStep + 1} of {ONBOARDING_STEPS.length}
        </p>
      </DialogContent>
    </Dialog>
  );
}

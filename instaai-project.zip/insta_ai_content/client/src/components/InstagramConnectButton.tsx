import { Button } from "@/components/ui/button";
import { Instagram, Loader2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

interface InstagramConnectButtonProps {
  onConnect?: () => void;
  isLoading?: boolean;
}

export function InstagramConnectButton({ onConnect, isLoading = false }: InstagramConnectButtonProps) {
  const [isConnecting, setIsConnecting] = useState(false);

  const handleConnect = async () => {
    setIsConnecting(true);
    try {
      // This is a placeholder for future Instagram OAuth integration
      // In production, this would:
      // 1. Redirect to Instagram OAuth flow
      // 2. Handle callback and token exchange
      // 3. Store tokens securely in database
      // 4. Enable direct publishing

      toast.info("Instagram OAuth integration coming soon!");

      // Simulate OAuth flow
      setTimeout(() => {
        setIsConnecting(false);
        onConnect?.();
      }, 1500);
    } catch (error) {
      toast.error("Failed to connect Instagram");
      setIsConnecting(false);
    }
  };

  return (
    <Button
      onClick={handleConnect}
      disabled={isLoading || isConnecting}
      className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-semibold"
    >
      {isConnecting || isLoading ? (
        <>
          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
          Connecting...
        </>
      ) : (
        <>
          <Instagram className="w-4 h-4 mr-2" />
          Connect Instagram Account
        </>
      )}
    </Button>
  );
}

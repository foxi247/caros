import { useState } from "react";
import { ChevronLeft, ChevronRight, Heart, MessageCircle, Send, Bookmark } from "lucide-react";
import type { CarouselPost, CarouselSlide } from "../types";

interface InstagramCarouselPreviewProps {
  post: CarouselPost;
  slides: CarouselSlide[];
}

export function InstagramCarouselPreview({ post, slides }: InstagramCarouselPreviewProps) {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isLiked, setIsLiked] = useState(false);

  const goToPrevious = () => {
    setCurrentSlide((prev) => (prev === 0 ? slides.length - 1 : prev - 1));
  };

  const goToNext = () => {
    setCurrentSlide((prev) => (prev === slides.length - 1 ? 0 : prev + 1));
  };

  const currentSlideData = slides[currentSlide];

  return (
    <div className="w-full max-w-md mx-auto">
      {/* Instagram Post Container */}
      <div className="bg-white dark:bg-card rounded-lg shadow-lg-glass overflow-hidden">
        {/* Header */}
        <div className="px-4 py-3 border-b border-border flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-accent opacity-70" />
            <div>
              <p className="font-semibold text-sm text-foreground">InstaAI</p>
              <p className="text-xs text-muted-foreground">Demo Account</p>
            </div>
          </div>
          <button className="text-foreground hover:text-muted-foreground">
            <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
              <circle cx="12" cy="5" r="2" />
              <circle cx="12" cy="12" r="2" />
              <circle cx="12" cy="19" r="2" />
            </svg>
          </button>
        </div>

        {/* Image/Slide Area */}
        <div className="relative bg-gradient-subtle aspect-square flex items-center justify-center overflow-hidden">
          {/* Slide Content */}
          <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center">
            {/* Background gradient based on color scheme */}
            <div className="absolute inset-0 bg-gradient-to-br from-accent/20 via-transparent to-accent/10" />

            {/* Slide Text */}
            <div className="relative z-10 space-y-4">
              <div
                className={`text-3xl md:text-4xl font-bold text-gradient ${
                  currentSlideData?.textAlignment === "left"
                    ? "text-left"
                    : currentSlideData?.textAlignment === "right"
                      ? "text-right"
                      : "text-center"
                }`}
              >
                {currentSlideData?.slideText || "Slide content"}
              </div>

              {currentSlideData?.visualDescription && (
                <p className="text-sm text-muted-foreground italic max-w-xs mx-auto">
                  {currentSlideData.visualDescription}
                </p>
              )}
            </div>
          </div>

          {/* Carousel Navigation */}
          {slides.length > 1 && (
            <>
              <button
                onClick={goToPrevious}
                className="absolute left-3 top-1/2 -translate-y-1/2 z-20 bg-black/40 hover:bg-black/60 text-white p-2 rounded-full transition-smooth"
                aria-label="Previous slide"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={goToNext}
                className="absolute right-3 top-1/2 -translate-y-1/2 z-20 bg-black/40 hover:bg-black/60 text-white p-2 rounded-full transition-smooth"
                aria-label="Next slide"
              >
                <ChevronRight className="w-5 h-5" />
              </button>

              {/* Slide Indicators */}
              <div className="absolute bottom-3 left-1/2 -translate-x-1/2 z-20 flex gap-1">
                {slides.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`h-1 rounded-full transition-smooth ${
                      index === currentSlide ? "w-6 bg-white" : "w-1 bg-white/50"
                    }`}
                    aria-label={`Go to slide ${index + 1}`}
                  />
                ))}
              </div>
            </>
          )}
        </div>

        {/* Actions */}
        <div className="px-4 py-3 border-b border-border flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setIsLiked(!isLiked)}
              className="text-foreground hover:text-muted-foreground transition-smooth"
            >
              <Heart
                className="w-6 h-6"
                fill={isLiked ? "currentColor" : "none"}
                color={isLiked ? "#ef4444" : "currentColor"}
              />
            </button>
            <button className="text-foreground hover:text-muted-foreground transition-smooth">
              <MessageCircle className="w-6 h-6" />
            </button>
            <button className="text-foreground hover:text-muted-foreground transition-smooth">
              <Send className="w-6 h-6" />
            </button>
          </div>
          <button className="text-foreground hover:text-muted-foreground transition-smooth">
            <Bookmark className="w-6 h-6" />
          </button>
        </div>

        {/* Likes and Caption */}
        <div className="px-4 py-3 space-y-2">
          <p className="text-sm font-semibold text-foreground">
            {isLiked ? "1,234" : "1,233"} likes
          </p>

          <div className="space-y-1">
            <p className="text-sm">
              <span className="font-semibold text-foreground">InstaAI</span>{" "}
              <span className="text-foreground line-clamp-3">{post.caption}</span>
            </p>
            <button className="text-xs text-muted-foreground hover:text-foreground transition-smooth">
              more
            </button>
          </div>

          {/* Comments Preview */}
          <p className="text-xs text-muted-foreground cursor-pointer hover:text-foreground transition-smooth">
            View all comments
          </p>
        </div>

        {/* Comment Input */}
        <div className="px-4 py-3 border-t border-border flex items-center gap-2">
          <input
            type="text"
            placeholder="Add a comment..."
            className="flex-1 bg-transparent text-sm text-foreground placeholder-muted-foreground focus:outline-none"
            disabled
          />
          <button className="text-accent font-semibold text-sm hover:text-accent/80 transition-smooth disabled:opacity-50">
            Post
          </button>
        </div>
      </div>

      {/* Slide Info */}
      <div className="mt-4 text-center text-sm text-muted-foreground">
        <p>
          Slide {currentSlide + 1} of {slides.length}
        </p>
      </div>
    </div>
  );
}

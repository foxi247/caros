import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { ContentGenerationForm } from "@/components/ContentGenerationForm";
import { InstagramCarouselPreview } from "@/components/InstagramCarouselPreview";
import { Sparkles, ArrowRight, Zap, Palette, Clock } from "lucide-react";
import { getLoginUrl } from "@/const";
import type { GenerationResult } from "@/types";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [generatedContent, setGeneratedContent] = useState<GenerationResult | null>(null);
  const [showPreview, setShowPreview] = useState(false);

  const handleGenerationSuccess = (result: GenerationResult) => {
    setGeneratedContent(result);
    setShowPreview(true);
  };

  return (
    <div className="min-h-screen bg-gradient-subtle">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 backdrop-blur-xl bg-background/80 border-b border-border">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-accent opacity-80" />
            <span className="font-bold text-lg text-foreground">InstaAI</span>
          </div>

          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <>
                <span className="text-sm text-muted-foreground">Welcome, {user?.name}</span>
                <Button variant="outline" size="sm">
                  Dashboard
                </Button>
              </>
            ) : (
              <a href={getLoginUrl()}>
                <Button size="sm">Sign In</Button>
              </a>
            )}
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="space-section container">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6 animate-slide-in-up">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 border border-accent/20">
              <Sparkles className="w-4 h-4 text-accent" />
              <span className="text-sm font-semibold text-accent">AI-Powered Content Creation</span>
            </div>

            <h1 className="text-5xl md:text-6xl font-bold leading-tight">
              Create <span className="text-gradient">Instagram Carousels</span> in Seconds
            </h1>

            <p className="text-lg text-muted-foreground max-w-lg">
              Generate engaging carousel posts with AI. Choose your niche, tone, and audience—we'll create the rest. No design skills needed.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button
                size="lg"
                className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold"
                onClick={() => setShowPreview(false)}
              >
                Try Demo Mode <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
              {!isAuthenticated && (
                <a href={getLoginUrl()}>
                  <Button size="lg" variant="outline">
                    Sign In to Save
                  </Button>
                </a>
              )}
            </div>
          </div>

          {/* Feature Cards */}
          <div className="grid gap-4">
            <div className="glass-card">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center flex-shrink-0">
                  <Zap className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-1">Lightning Fast</h3>
                  <p className="text-sm text-muted-foreground">Generate complete carousels in under 30 seconds</p>
                </div>
              </div>
            </div>

            <div className="glass-card">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center flex-shrink-0">
                  <Palette className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-1">Visual Suggestions</h3>
                  <p className="text-sm text-muted-foreground">Get color schemes and design recommendations</p>
                </div>
              </div>
            </div>

            <div className="glass-card">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center flex-shrink-0">
                  <Clock className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-1">Schedule Posts</h3>
                  <p className="text-sm text-muted-foreground">Plan and schedule content for later</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Demo Section */}
      <section className="space-section container">
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Form */}
          <div className="glass-card">
            <h2 className="text-2xl font-bold text-foreground mb-6">Create Your First Carousel</h2>
            <ContentGenerationForm onSuccess={handleGenerationSuccess} />
          </div>

          {/* Preview */}
          <div className="space-y-4">
            {showPreview && generatedContent ? (
              <>
                <div className="glass-card p-0 overflow-hidden">
                  <InstagramCarouselPreview
                    post={generatedContent.post!}
                    slides={generatedContent.slides}
                  />
                </div>

                <div className="glass-card">
                  <h3 className="font-semibold text-foreground mb-3">Post Details</h3>
                  <div className="space-y-3 text-sm">
                    <div>
                      <p className="text-muted-foreground">Title</p>
                      <p className="text-foreground font-medium">{generatedContent.post?.title}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Visual Style</p>
                      <p className="text-foreground font-medium">{generatedContent.post?.visualStyle}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Slides</p>
                      <p className="text-foreground font-medium">{generatedContent.slides.length} slides</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Generation Time</p>
                      <p className="text-foreground font-medium">{generatedContent.generationTimeMs}ms</p>
                    </div>
                  </div>
                </div>

                {isAuthenticated && (
                  <div className="glass-card">
                    <Button className="w-full bg-accent hover:bg-accent/90 text-accent-foreground font-semibold">
                      Connect Instagram & Publish
                    </Button>
                  </div>
                )}
              </>
            ) : (
              <div className="glass-card h-96 flex items-center justify-center">
                <div className="text-center space-y-3">
                  <div className="w-16 h-16 rounded-full bg-accent/10 flex items-center justify-center mx-auto">
                    <Sparkles className="w-8 h-8 text-accent" />
                  </div>
                  <p className="text-muted-foreground">
                    Fill out the form to see your carousel preview here
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="space-section container">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-foreground mb-4">Why Choose InstaAI?</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Everything you need to create professional Instagram content without the design skills
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              title: "AI-Powered",
              description: "Advanced AI generates engaging content tailored to your audience",
              icon: "✨",
            },
            {
              title: "Multiple Languages",
              description: "Create content in 10+ languages to reach global audiences",
              icon: "🌍",
            },
            {
              title: "Instant Preview",
              description: "See exactly how your carousel will look on Instagram",
              icon: "👁️",
            },
            {
              title: "Smart Scheduling",
              description: "Schedule posts at optimal times for maximum engagement",
              icon: "⏰",
            },
            {
              title: "Analytics Ready",
              description: "Track performance and optimize future content",
              icon: "📊",
            },
            {
              title: "No Design Skills",
              description: "Professional results without needing design experience",
              icon: "🎨",
            },
          ].map((feature, index) => (
            <div key={index} className="glass-card">
              <div className="text-4xl mb-3">{feature.icon}</div>
              <h3 className="font-semibold text-foreground mb-2">{feature.title}</h3>
              <p className="text-sm text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="space-section container">
        <div className="glass-card text-center py-12">
          <h2 className="text-3xl font-bold text-foreground mb-4">Ready to Transform Your Instagram?</h2>
          <p className="text-muted-foreground mb-8 max-w-xl mx-auto">
            Start creating amazing carousel posts today. Try demo mode first, no sign-up required.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="bg-accent hover:bg-accent/90 text-accent-foreground font-semibold"
              onClick={() => setShowPreview(false)}
            >
              Start Creating
            </Button>
            {!isAuthenticated && (
              <a href={getLoginUrl()}>
                <Button size="lg" variant="outline">
                  Sign In
                </Button>
              </a>
            )}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8 mt-12">
        <div className="container text-center text-sm text-muted-foreground">
          <p>© 2026 InstaAI. All rights reserved. Demo mode available for all users.</p>
        </div>
      </footer>
    </div>
  );
}

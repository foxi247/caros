import { useAuth } from "@/_core/hooks/useAuth";
import { useRoute } from "wouter";
import { useEffect } from "react";
import DashboardLayout from "@/components/DashboardLayout";
import { Card } from "@/components/ui/card";
import { Users, Instagram, FileText, Clock, TrendingUp, Activity } from "lucide-react";
import { trpc } from "@/lib/trpc";

export default function AdminDashboard() {
  const { user, isAuthenticated } = useAuth();
  const [match] = useRoute("/admin");

  // Redirect non-admins
  useEffect(() => {
    if (isAuthenticated && user?.role !== "admin" && match) {
      window.location.href = "/";
    }
  }, [isAuthenticated, user?.role, match]);

  const { data: stats, isLoading } = trpc.admin.getStats.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });

  if (!isAuthenticated || user?.role !== "admin") {
    return null;
  }

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-foreground">Admin Dashboard</h1>
          <p className="text-muted-foreground mt-2">Platform overview and management</p>
        </div>

        {/* Stats Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="glass-card">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Total Users</p>
                <p className="text-3xl font-bold text-foreground">
                  {isLoading ? "..." : stats?.totalUsers || 0}
                </p>
              </div>
              <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center">
                <Users className="w-6 h-6 text-accent" />
              </div>
            </div>
          </Card>

          <Card className="glass-card">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Connected Accounts</p>
                <p className="text-3xl font-bold text-foreground">
                  {isLoading ? "..." : stats?.connectedAccounts || 0}
                </p>
              </div>
              <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center">
                <Instagram className="w-6 h-6 text-accent" />
              </div>
            </div>
          </Card>

          <Card className="glass-card">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Total Posts</p>
                <p className="text-3xl font-bold text-foreground">
                  {isLoading ? "..." : stats?.totalPosts || 0}
                </p>
              </div>
              <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center">
                <FileText className="w-6 h-6 text-accent" />
              </div>
            </div>
          </Card>

          <Card className="glass-card">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Scheduled Posts</p>
                <p className="text-3xl font-bold text-foreground">
                  {isLoading ? "..." : stats?.scheduledPosts || 0}
                </p>
              </div>
              <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center">
                <Clock className="w-6 h-6 text-accent" />
              </div>
            </div>
          </Card>
        </div>

        {/* Users Table */}
        <Card className="glass-card">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-foreground">Recent Users</h2>
            <Users className="w-5 h-5 text-muted-foreground" />
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Name</th>
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Email</th>
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Role</th>
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Joined</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr>
                    <td colSpan={4} className="py-8 text-center text-muted-foreground">
                      Loading...
                    </td>
                  </tr>
                ) : stats?.users && stats.users.length > 0 ? (
                  stats.users.slice(0, 10).map((u) => (
                    <tr key={u.id} className="border-b border-border/50 hover:bg-muted/50 transition-smooth">
                      <td className="py-3 px-4 text-foreground">{u.name || "Unnamed"}</td>
                      <td className="py-3 px-4 text-muted-foreground">{u.email || "-"}</td>
                      <td className="py-3 px-4">
                        <span className={`px-2 py-1 rounded text-xs font-semibold ${
                          u.role === "admin"
                            ? "bg-accent/20 text-accent"
                            : "bg-muted text-muted-foreground"
                        }`}>
                          {u.role}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-muted-foreground">
                        {new Date(u.createdAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={4} className="py-8 text-center text-muted-foreground">
                      No users yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Connected Accounts Table */}
        <Card className="glass-card">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-foreground">Connected Instagram Accounts</h2>
            <Instagram className="w-5 h-5 text-muted-foreground" />
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Username</th>
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Status</th>
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Connected</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr>
                    <td colSpan={3} className="py-8 text-center text-muted-foreground">
                      Loading...
                    </td>
                  </tr>
                ) : stats?.accounts && stats.accounts.length > 0 ? (
                  stats.accounts.slice(0, 10).map((acc) => (
                    <tr key={acc.id} className="border-b border-border/50 hover:bg-muted/50 transition-smooth">
                      <td className="py-3 px-4 text-foreground">@{acc.instagramUsername}</td>
                      <td className="py-3 px-4">
                        <span className="px-2 py-1 rounded text-xs font-semibold bg-green-500/20 text-green-600 dark:text-green-400">
                          Connected
                        </span>
                      </td>
                      <td className="py-3 px-4 text-muted-foreground">
                        {new Date(acc.createdAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={3} className="py-8 text-center text-muted-foreground">
                      No connected accounts yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Generated Posts Table */}
        <Card className="glass-card">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-foreground">Recent Generated Posts</h2>
            <FileText className="w-5 h-5 text-muted-foreground" />
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Title</th>
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Niche</th>
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Slides</th>
                  <th className="text-left py-3 px-4 font-semibold text-foreground">Created</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  <tr>
                    <td colSpan={4} className="py-8 text-center text-muted-foreground">
                      Loading...
                    </td>
                  </tr>
                ) : stats?.posts && stats.posts.length > 0 ? (
                  stats.posts.slice(0, 10).map((post) => (
                    <tr key={post.id} className="border-b border-border/50 hover:bg-muted/50 transition-smooth">
                      <td className="py-3 px-4 text-foreground font-medium">{post.title}</td>
                      <td className="py-3 px-4 text-muted-foreground">{post.niche}</td>
                      <td className="py-3 px-4 text-muted-foreground">{post.slideCount}</td>
                      <td className="py-3 px-4 text-muted-foreground">
                        {new Date(post.createdAt).toLocaleDateString()}
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={4} className="py-8 text-center text-muted-foreground">
                      No posts yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>

        {/* Activity Summary */}
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="glass-card">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center flex-shrink-0">
                <TrendingUp className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-1">Growth</h3>
                <p className="text-sm text-muted-foreground">Platform is growing steadily with new users and content</p>
              </div>
            </div>
          </Card>

          <Card className="glass-card">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-lg bg-accent/20 flex items-center justify-center flex-shrink-0">
                <Activity className="w-6 h-6 text-accent" />
              </div>
              <div>
                <h3 className="font-semibold text-foreground mb-1">Activity</h3>
                <p className="text-sm text-muted-foreground">High engagement with content generation features</p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}

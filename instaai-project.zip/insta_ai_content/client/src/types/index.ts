export interface CarouselPost {
  id: number;
  userId: number | null;
  title: string;
  niche: string;
  toneOfVoice: string;
  language: string;
  targetAudience: string;
  caption: string;
  visualStyle: string | null;
  slideCount: number;
  isScheduled: boolean;
  scheduledFor: Date | null;
  isPublished: boolean;
  publishedAt: Date | null;
  instagramPostId: string | null;
  createdAt: Date;
  updatedAt: Date;
}

export interface CarouselSlide {
  id: number;
  postId: number;
  slideNumber: number;
  slideText: string;
  visualDescription: string | null;
  colorScheme: string | null;
  textAlignment: "center" | "left" | "right";
  createdAt: Date;
  updatedAt: Date;
}

export interface GenerationInput {
  niche: string;
  toneOfVoice: string;
  language: string;
  targetAudience: string;
}

export interface GenerationResult {
  success: boolean;
  post: CarouselPost;
  slides: CarouselSlide[];
  generationTimeMs: number;
}
